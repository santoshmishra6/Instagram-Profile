<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>District Form</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/jquery.validation/1.19.3/jquery.validate.min.js"></script>
    <style>
     body {
    background: linear-gradient(135deg, #1e3c72, #2a5298);
    height: 100vh;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 20px;
    font-family: Arial, sans-serif;
    margin: 0;
    height: 120vh;
}

.card {
    background: rgba(255, 255, 255, 0.1);
    padding: 30px;
    border-radius: 15px;
    box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
    backdrop-filter: blur(10px);
    color: white;
    text-align: center;
    width: 400px;
    transition: transform 0.3s ease-in-out;
}

.card:hover {
    transform: translateY(-5px);
}

.card label {
    font-weight: bold;
    color: white;
}

.card select,
.card input {
    background: rgba(255, 255, 255, 0.2);
    border: none;
    color: white;
    padding: 10px;
    border-radius: 8px;
    width: 100%;
    margin-top: 5px;
    box-shadow: inset 2px 2px 5px rgba(255, 255, 255, 0.2),
                inset -2px -2px 5px rgba(0, 0, 0, 0.2);
}

.card select:focus,
.card input:focus {
    outline: none;
    border: 2px solid #ff4b5c;
    box-shadow: 0px 0px 8px rgba(255, 255, 255, 0.5);
} 
.card select option {
    background-color: black;
    color: white;
}

.card input::placeholder {
    color: rgba(255, 255, 255, 0.7);
}

.btn-primary {
    background-color: #ff4b5c;
    border: none;
    padding: 10px;
    border-radius: 12px;
    transition: 0.3s;
    font-size: 16px;
    box-shadow: 0px 5px 15px rgba(0, 0, 0, 0.3);
    width: 100%;
}

.btn-primary:hover {
    background-color: #ff1e3c;
    transform: scale(1.05);
    box-shadow: 0px 8px 20px rgba(255, 0, 0, 0.5);
}

.error {
    color: #ff4b5c;
    font-size: 14px;
    margin-top: 5px;
    text-align: left;
}

.table-container {
    margin-top: 20px;
    text-align: center;
}

table {
    width: 100%;
    border-collapse: collapse;
    color: white;
}

th, td {
    border: 1px solid rgba(255, 255, 255, 0.5);
    padding: 8px;
}

th {
    background: rgba(255, 255, 255, 0.2);
}

@media (max-width: 480px) {
    .card {
        width: 90%;
        padding: 20px;
    }
}

    </style>
</head>

<body>
    <div class="card">
        <a href="AddState.php" class="btn btn-primary">Back</a>
        <h3 class="mt-3">District Form</h3>
        <form id="myForm" action="" method="POST">
            <div class="form-group mt-3">
                <label for="select">Select State</label>
                <select name="state_id" id="select">
                    <option value="">--Select State--</option>
                    <?php
                    require('db.php');
                    $state = "SELECT * FROM state";
                    $res = $con->query($state);

                    while ($row = $res->fetch_assoc()) {
                        echo '<option value="' . $row['id'] . '">' . $row['name'] . '</option>';
                    }
                    ?>
                </select>
                <span id="selectError" class="error"></span>
            </div>

            <div class="form-group mt-3">
                <label for="name">Enter District Name</label>
                <input type="text" id="name" name="name" placeholder="Enter District Name">
                <span id="nameError" class="error"></span>
            </div>

            <button type="submit" class="btn btn-primary mt-3">Submit</button>
        </form>

        <div class="table-container">
            <h3>District List</h3>
            <table>
                <tr>
                    <th>Sl No.</th>
                    <th>District Name</th>
                    <th>State Name</th>
                </tr>
                <?php
                $sql = "SELECT d.name as district_name, s.name as state_name FROM district d 
                        JOIN state s ON d.state_id = s.id ORDER BY s.name, d.name";
                $res = $con->query($sql);
                $var = 1;

                if ($res->num_rows > 0) {
                    while ($row = $res->fetch_assoc()) {
                        echo "<tr>
                                <td>" . $var++ . "</td>
                                <td>" . $row['district_name'] . "</td>
                                <td>" . $row['state_name'] . "</td>
                              </tr>";
                    }
                }
                ?>
            </table>
        </div>
    </div>

    <script>
        $(document).ready(function() {
            $("#myForm").submit(function(e) {
                var valid = true;
                var select = $("#select").val();
                var name = $("#name").val();
                var vname = /^[a-zA-Z ]+$/;

                $(".error").text("");

                if (select === "") {
                    $("#selectError").text("Please select a State");
                    valid = false;
                } else if (name === "") {
                    $("#nameError").text("Please enter your District Name!");
                    valid = false;
                } else if (!vname.test(name)) {
                    $("#nameError").text("Only letters are allowed in the District Name!");
                    valid = false;
                } else if (/^\s/.test(name)) {
                    $("#nameError").text("Error: Input should not start with spaces!");
                    valid = false;
                }

                if (!valid) {
                    e.preventDefault();
                }
            });
        });
    </script>
</body>

</html>
