<?php
session_start();
require("db.php");

$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $select = trim($_POST['select']);
    $username = trim($_POST['username']);
    $pass = md5($_POST['pass']);

    $sql = "SELECT * FROM registration WHERE username='$username' and pass='$pass'";
    $result = $con->query($sql);

    // $admin_sql="select * from "

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        // echo 'ndfv';exit;
        if ($pass == $row['pass']) {
            $_SESSION['id'] = $row['id'];
            echo "<script>alert('Login Successful'); 
            window.location='view.php';</script>";
        } else {
            $message = '<div class="alert alert-danger">Invalid password.</div>';
        }
    } else {
        $message = '<div class="alert alert-danger">User not found.</div>';
    }
}
$con->close();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Form</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <style>
        body {
            color: #000;
            overflow-x: hidden;
            height: 100%;
            background-image: linear-gradient(to right, #11998E, #38EF7D);
            background-repeat: no-repeat;
            margin: 0;
            padding: 0;
        }

        .welcome-img {
            width: 100%;
            max-width: 450px;
            height: auto;
            border-radius: 20px;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.2);
            transition: transform 0.3s ease-in-out;
        }

        .welcome-img:hover {
            transform: scale(1.05);
            /* Slight zoom effect on hover */
        }

        input,
        textarea {
            background-color: #F3E5F5;
            border-radius: 50px !important;
            padding: 12px 15px !important;
            width: 100%;
            box-sizing: border-box;
            border: 1px solid #F3E5F5 !important;
            font-size: 16px !important;
            color: #000 !important;
            font-weight: 400;
        }

        input:focus,
        textarea:focus {
            box-shadow: none !important;
            border: 1px solid #D500F9 !important;
            outline-width: 0;
        }

        .card {
            border-radius: 0;
            border: none;
        }

        .card0 {
            height: 100%;
        }

        .card1,
        .card2 {
            height: 100%;
        }


        .btn-color {
            border-radius: 50px;
            color: #fff;
            background-image: linear-gradient(to right, #FFD54F, #D500F9);
            padding: 15px;
            cursor: pointer;
            border: none !important;
            margin-top: 40px;
        }

        .btn-white {
            border-radius: 50px;
            color: #D500F9;
            background-color: #fff;
            padding: 8px 40px;
            cursor: pointer;
            border: 2px solid #D500F9 !important;
        }

        .bottom {
            width: 100%;
            margin-top: 50px !important;
        }

        .error {
            color: rgb(248, 27, 252);
        }
    </style>
</head>

<body>
    <div class="container px-4 py-5 mx-auto">
        <div class="card card0">
            <div class="d-flex flex-lg-row flex-column-reverse justify-content-center">
                <div class="card card1">
                    <div class="row justify-content-center my-auto">
                        <div class="col-md-8 col-10 my-5">
                            <div class="row justify-content-center px-3 mb-3">
                                <img id="logo" src="welcome.jpg" class="welcome-img">
                            </div>

                            <form id="loginForm" method="post">
                                <div class="form-group">
                                    <label class="form-control-label text-muted">Select Role</label>
                                    <select id="role" name="select" class="form-control">
                                        <option value="admin">Admin</option>
                                        <option value="user">User</option>
                                    </select>
                                </div>
                                <?= $message; ?>
                                <div class="form-group">
                                    <label class="form-control-label text-muted">Username</label>
                                    <input type="text" id="username" name="username" placeholder="Username" class="form-control">
                                    <div class="error" id="userError"></div>
                                </div>
                                <div class="form-group">
                                    <label class="form-control-label text-muted">Password</label>
                                    <input type="password" id="pass" name="pass" placeholder="Password" class="form-control">
                                    <div class="error" id="passError"></div>
                                </div>
                                <div class="row my-3 px-3 text-center">
                                    <button type="submit" class="btn-block btn-color">Login</button>
                                </div>
                            </form>
                        </div>
                    </div>
                    <div class="bottom text-center mb-5" style="display: inline;">
                        <label for="registerCheck">Check to Register</label> <input type="checkbox" id="check">
                        <div class="error" id="checkError"></div>
                        <div class="form-group text-center" style="display: inline-block;">
                            <a href="registration.php" class="btn btn-white ml-2" id="registration">Registration</a>
                        </div>
                    </div>
                </div>
            </div>
            <script>
                $(document).ready(function() {
                    $("#loginForm").submit(function(e) {
                        var valid = true;
                        var username = $("#username").val();
                        var pass = $("#pass").val().trim();
                        $(".error").text("");
                        if (username === "") {
                            $("#userError").text("Username cannot be empty!");
                            valid = false;
                        } else if (/^\s/.test(username)) {
                            $("#userError").text("Username should not start with spaces!");
                            valid = false;
                        }
                        if (pass === "") {
                            $("#passError").text("Password cannot be empty!");
                            valid = false;
                        } else if (/^\s/.test(pass)) {
                            $("#passError").text("Password should not start with spaces!");
                            valid = false;
                        }
                        if (!valid) {
                            e.preventDefault();
                        }
                    });
                    $("#registration").click(function(e) {
                        if (!$("#check").is(":checked")) {
                            $("#checkError").text("You must agree if you are a new user.");
                            e.preventDefault();
                        }
                    });
                });
            </script>
        </div>
    </div>
</body>

</html>