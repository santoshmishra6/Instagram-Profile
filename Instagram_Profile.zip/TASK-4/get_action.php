<?php
require("db.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $task_id = $_POST['id']; 
    $action = $_POST['action']; 

    $sql = "UPDATE task SET action = $action WHERE id = $task_id";
    $result=$con->query($sql);
}
$con->close();
?>
