<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/css/bootstrap.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <title>Login</title>
    <style>
        body {
            background: linear-gradient(135deg, #1e3c72, #2a5298);
            height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
            font-family: Arial, sans-serif;
        }

        .card {
            background: rgba(255, 255, 255, 0.1);
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
            backdrop-filter: blur(10px);
            color: white;
            text-align: center;
            width: 400px;
        }

        .form-group input {
            background: rgba(255, 255, 255, 0.2);
            border: none;
            padding: 12px;
            width: 100%;
            border-radius: 8px;
            color: white;
            font-size: 16px;
        }

        .btn-submit {
            background: rgba(255, 255, 255, 0.2);
            border: none;
            color: white;
            padding: 12px;
            width: 100%;
            border-radius: 10px;
            font-size: 18px;
            font-weight: bold;
            transition: 0.3s;
            margin-top: 15px;
        }

        .btn-submit:hover {
            background: rgba(255, 255, 255, 0.4);
            transform: scale(1.05);
        }
    </style>
</head>
<body>
    <div class="card">
        <h5>Login</h5>
        <form id="loginForm" method="post">
            <div class="form-group">
                <input type="text" id="username" name="username" placeholder="Username" required>
            </div>
            <div class="form-group">
                <input type="password" id="pass" name="pass" placeholder="Password" required>
            </div>
            <button type="submit" class="btn-submit">Login</button>
        </form>
    </div>
</body>
</html>
