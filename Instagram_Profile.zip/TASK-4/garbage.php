<?php
session_start();
require("db.php");

$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $username = trim($_POST['username']);
    $pass = md5($_POST['pass']);
                                   
    $sql = "SELECT * FROM registration WHERE username='$username' and pass='$pass'";
    $result = $con->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
// echo 'ndfv';exit;
        if ($pass==$row['pass']) {
            $_SESSION['id'] = $row['id'];
            echo "<script>alert('Login Successful'); 
            window.location='view.php';</script>";
        } else {
            $message = '<div class="alert alert-danger">Invalid password.</div>';
        }
    } else {
        $message = '<div class="alert alert-danger">User not found.</div>';
    }
}
$con->close();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/css/bootstrap.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <title>Login | CRUD</title>
    <style>
        body {
            background-color: #f8f9fa;
        }

        .login-container {
            max-width: 400px;
            margin: 50px auto;
        }

        .card {
            border-radius: 10px;
        }

        .btn {
            width: 100%;
        }

        .error {
            color: red;
        }
    </style>
</head>

<body>
    <!-- <div class="container">
        <div class="login-container">
            <div class="card shadow">
                <div class="card-body">
                    <h2 class="text-center mb-4">Login</h2>

                    <?= $message; ?>
                    <form id="loginForm" method="post">
                        <div class="form-group">
                            <label for="username">Username</label>
                            <input type="text" class="form-control" id="username" name="username" placeholder="Enter Username">
                            <div class="error" id="userError"></div>
                        </div>

                        <div class="form-group">
                            <label for="pass">Password</label>
                            <input type="password" class="form-control" name="pass" id="pass" placeholder="Enter Password">
                            <div class="error" id="passError"></div>
                        </div>

                        <button type="submit" class="btn btn-success mb-3">Login</button>

                        <div class="form-check">
                            <input type="checkbox" class="form-check-input" id="check">
                            <label class="form-check-label" for="check">If New User</label>
                            <div class="error" id="checkError"></div>
                        </div>

                        <a href="registration.php" class="btn btn-outline-primary mt-3" id="registration">Register</a>
                    </form>
                </div>
            </div>
        </div>
    </div> -->
    <form class="row g-3 needs-validation" novalidate>
  <div class="col-md-4">
    <label for="validationCustom01" class="form-label">First name</label>
    <input type="text" class="form-control" id="validationCustom01" value="Mark" required>
    <div class="valid-feedback">
      Looks good!
    </div>
  </div>
  <div class="col-md-4">
    <label for="validationCustom02" class="form-label">Last name</label>
    <input type="text" class="form-control" id="validationCustom02" value="Otto" required>
    <div class="valid-feedback">
      Looks good!
    </div>
  </div>
  <div class="col-md-4">
    <label for="validationCustomUsername" class="form-label">Username</label>
    <div class="input-group has-validation">
      <span class="input-group-text" id="inputGroupPrepend">@</span>
      <input type="text" class="form-control" id="validationCustomUsername" aria-describedby="inputGroupPrepend" required>
      <div class="invalid-feedback">
        Please choose a username.
      </div>
    </div>
  </div>
  <div class="col-md-6">
    <label for="validationCustom03" class="form-label">City</label>
    <input type="text" class="form-control" id="validationCustom03" required>
    <div class="invalid-feedback">
      Please provide a valid city.
    </div>
  </div>
  <div class="col-md-3">
    <label for="validationCustom04" class="form-label">State</label>
    <select class="form-select" id="validationCustom04" required>
      <option selected disabled value="">Choose...</option>
      <option>...</option>
    </select>
    <div class="invalid-feedback">
      Please select a valid state.
    </div>
  </div>
  <div class="col-md-3">
    <label for="validationCustom05" class="form-label">Zip</label>
    <input type="text" class="form-control" id="validationCustom05" required>
    <div class="invalid-feedback">
      Please provide a valid zip.
    </div>
  </div>
  <div class="col-12">
    <div class="form-check">
      <input class="form-check-input" type="checkbox" value="" id="invalidCheck" required>
      <label class="form-check-label" for="invalidCheck">
        Agree to terms and conditions
      </label>
      <div class="invalid-feedback">
        You must agree before submitting.
      </div>
    </div>
  </div>
  <div class="col-12">
    <button class="btn btn-primary" type="submit">Submit form</button>
  </div>
</form>
    <script>
// Example starter JavaScript for disabling form submissions if there are invalid fields
(function () {
  'use strict'

  // Fetch all the forms we want to apply custom Bootstrap validation styles to
  var forms = document.querySelectorAll('.needs-validation')

  // Loop over them and prevent submission
  Array.prototype.slice.call(forms)
    .forEach(function (form) {
      form.addEventListener('submit', function (event) {
        if (!form.checkValidity()) {
          event.preventDefault()
          event.stopPropagation()
        }

        form.classList.add('was-validated')
      }, false)
    })
})()




        // $(document).ready(function() {
        //     $("#loginForm").submit(function(e) {
        //         var valid = true;
        //         var username = $("#username").val();
        //         var pass = $("#pass").val();
        //         // var regPass = /^(?=.*[!@#$%^&*()_+{}\[\]:;<>,.?~\\/-]).{5,}$/;

        //         $(".error").text(""); // Clear previous error messages

        //         if (username === "") {
        //             $("#userError").text("Username cannot be empty!");
        //             valid = false;
        //         } else if (/^\s/.test(username)) {
        //             $("#userError").text("Username should not start with spaces!");
        //             valid = false;
        //         }

        //         if (pass === "") {
        //             $("#passError").text("Password cannot be empty!");
        //             valid = false;
        //         } else if (/^\s/.test(pass)) {
        //             $("#passError").text("Password should not start with spaces!");
        //             valid = false;
        //         }

        //         if (!valid)
        //             e.preventDefault();
        //     });

        //     $("#registration").click(function(e) {
        //         var check = $("#check").is(":checked");
        //         if (!check) {
        //             $("#checkError").text("You must agree if you are a new user.");
        //             e.preventDefault();
        //         }
        //     });
        // });
    </script>
</body>

</html>