<?php
session_start();
require('db.php');
$msg = "";
if (!isset($_SESSION['id'])) {
    header("Location: index.php");
    exit();
} else {
    $id = $_SESSION['id'];

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $task = trim($_POST["task"]);
        $description = trim($_POST['description']);
        $status = strtolower(trim($_POST["status"]));

        $sql = "INSERT INTO task (task, description,status, reg_id) VALUES ('$task', '$description','$status', '$id')";
        if ($con->query($sql)) {
            $msg = '<div class="alert alert-danger">Data Successfully Inserted.</div>';
        } else {
            $msg = '<div class="alert alert-danger">Failed to insert data. Please try again.</div>';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Task Submission</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <style>
        body {
            background: linear-gradient(135deg, #1e3c72, #2a5298);
            height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
            font-family: Arial, sans-serif;
        }

        .card {
            background: rgba(255, 255, 255, 0.1);
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
            backdrop-filter: blur(10px);
            color: white;
            text-align: center;
            width: 400px;
        }

        .card input,
        .card textarea {
            background: rgba(255, 255, 255, 0.2);
            border: none;
            color: white;
            padding: 10px;
        }

        .card input::placeholder,
        .card textarea::placeholder {
            color: rgba(255, 255, 255, 0.7);
        }

        .card input:focus,
        .card textarea:focus {
            outline: none;
            border: 2px solid #ff4b5c;
        }

        .btn-primary {
            background-color: #ff4b5c;
            border: none;
            transition: 0.3s;
        }

        .btn-primary:hover {
            background-color: #ff1e3c;
            transform: scale(1.05);
        }

        .error {
            color: red;
        }
    </style>
</head>

<body>
    <div class="card">
        <?php echo $msg; ?>
        <form action="" method="post" id="task">
            <a href="dashboardTask.php" class="btn btn-secondary mb-3">Back</a>

            <div class="mb-3">
                <textarea class="form-control" rows="3" placeholder="Your Task" name="task" id="taskInput"></textarea>

                <div class="error" id="taskError"></div>
            </div>
            <div class="mb-3">
                <textarea class="form-control" rows="4" placeholder="Your Description" name="description" id="description"></textarea>
                <div class="error" id="descriptionError"></div>
            </div>
            <div class="mb-3">
                <input type="text" class="form-control" placeholder="Enter Status" name="status" id="status">
                <div class="error" id="statusError"></div>
            </div>
            <button type="submit" class="btn btn-primary w-100">Submit Task</button>
        </form>
    </div>
    <script>
        $(document).ready(function() {
            $("#task").submit(function(e) {
                var valid = true;
                var task = $("#taskInput").val();
                var description = $("#description").val();
                var status = $("#status").val();

                $(".error").text("");

                if (task === "") {
                    $("#taskError").text("Field cannot be empty!");
                    valid = false;
                } else if (/^\s/.test(task)) {
                    $("#taskError").text("Should not start with spaces!");
                    valid = false;
                }

                if (description === "") {
                    $("#descriptionError").text("Field cannot be empty!");
                    valid = false;
                } else if (/^\s/.test(description)) {
                    $("#descriptionError").text("Should not start with spaces!");
                    valid = false;
                }

                if (status === "") {
                    $("#statusError").text("Field cannot be empty!");
                    valid = false;
                } else if (/^\s/.test(status)) {
                    $("#statusError").text("Should not start with spaces!");
                    valid = false;
                }

                if (!valid) {
                    e.preventDefault();
                }
            });
        });
    </script>
</body>

</html>
<?php
$con->close();
?>