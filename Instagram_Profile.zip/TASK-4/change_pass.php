<?php
session_start();
require('db.php');

if (!isset($_SESSION['id'])) {
    echo "<script>alert('Unauthorized Access.'); window.location='index.php';</script>";
    exit();
}
else{
    $id = $_SESSION['id'];
    if ($_SERVER['REQUEST_METHOD'] == "POST") {
        $oldpass = md5($_POST['oldpass']);
        $newpass = md5($_POST['pass']);
        // echo "select pass from registration where id='$id";exit;
        $sql = "select pass from registration where id='$id'";
        $res = $con->query($sql);
        $row = $res->fetch_assoc();
        if ($oldpass == $row['pass']) {
            $update = "update registration set pass='$newpass' where id='$id'";
            $result = $con->query($update);
            if ($result) {
                echo "<script>alert('Password Changed');
                window.location='logout2.php';</script>";
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/css/bootstrap.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <title>Change Password</title>
    <style>
        body {
            padding: 125px;
            height: 100vh;
            background: linear-gradient(135deg, #1e3c72, #2a5298);
            background-repeat: no-repeat;
        }

        .login-container {
            max-width: 400px;
            margin: 50px auto;
            transition: transform 0.3s ease-in-out;
            background: rgba(255, 255, 255, 0.2);
            border-radius: 15px;
        }

        .login-container:hover {
            transform: scale(1.75);
        }


        .password-container {
            position: relative;
            display: flex;
            align-items: center;
            width: 100%;
        }

        .form-control {
            width: 100%;
            padding-right: 40px;
            /* Space for the button */
        }

        .toggle-btn {
            position: absolute;
            right: 10px;
            background: none;
            border: none;
            cursor: pointer;
            outline: none;
        }

        .toggle-btn svg {
            width: 20px;
            height: 20px;
        }

        .error {
            color: rgb(255, 0, 0);
            font-size: 14px;
        }
    </style>
</head>

<body>
    <div class="container">
        <div class="login-container">
            <!-- <div class="card shadow"> -->
            <div class="p-4 shadow">
                <a href="view.php" class="btn btn-secondary">Back</a>
                <h5 class="text-center">Change Password</h5><br>
                <form action="" method="post" id="myForm">
                    <div class="form-group">
                        <div class="password-container">
                            <input type="password" class="form-control oldpass" placeholder="Enter Old Password" name="oldpass" id="oldpass">
                            <button class="toggle-btn" type="button" onclick="showoldPassword()">
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-eye" viewBox="0 0 16 16">
                                    <path d="M16 8s-3-5.5-8-5.5S0 8 0 8s3 5.5 8 5.5S16 8 16 8M1.173 8a13 13 0 0 1 1.66-2.043C4.12 4.668 5.88 3.5 8 3.5s3.879 1.168 5.168 2.457A13 13 0 0 1 14.828 8q-.086.13-.195.288c-.335.48-.83 1.12-1.465 1.755C11.879 11.332 10.119 12.5 8 12.5s-3.879-1.168-5.168-2.457A13 13 0 0 1 1.172 8z" />
                                    <path d="M8 5.5a2.5 2.5 0 1 0 0 5 2.5 2.5 0 0 0 0-5M4.5 8a3.5 3.5 0 1 1 7 0 3.5 3.5 0 0 1-7 0" />
                                </svg>
                            </button>
                        </div>
                        <div class="error" id="oldpassError"></div><br>
                    </div>
                    <div class="form-group">
                        <input type="password" class="form-control" placeholder="Enter New Password" name="pass" id="pass">
                        <div class="error" id="passError"></div><br>
                    </div>
                    <div class="password-container">
                        <input type="password" class="form-control" placeholder="Confirm New Password" id="newpass">
                        <button class="toggle-btn" type="button" onclick="shownewPassword()">
                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-eye" viewBox="0 0 16 16">
                                <path d="M16 8s-3-5.5-8-5.5S0 8 0 8s3 5.5 8 5.5S16 8 16 8M1.173 8a13 13 0 0 1 1.66-2.043C4.12 4.668 5.88 3.5 8 3.5s3.879 1.168 5.168 2.457A13 13 0 0 1 14.828 8q-.086.13-.195.288c-.335.48-.83 1.12-1.465 1.755C11.879 11.332 10.119 12.5 8 12.5s-3.879-1.168-5.168-2.457A13 13 0 0 1 1.172 8z" />
                                <path d="M8 5.5a2.5 2.5 0 1 0 0 5 2.5 2.5 0 0 0 0-5M4.5 8a3.5 3.5 0 1 1 7 0 3.5 3.5 0 0 1-7 0" />
                            </svg>
                        </button>
                        <br>
                    </div>
                    <div class="error" id="newpassError"></div><br><br>
                    <div class="d-flex justify-content-center">
                        <input type="submit" class="btn btn-primary" value="Change Password">
                    </div>
                </form>
            </div>
        </div>
    </div>
    </div>

    <script>
        $(document).ready(function() {
            $("#myForm").submit(function(e) {
                var valid = true;
                var oldpass = $("#oldpass").val().trim();
                var pass = $("#pass").val().trim();
                var newpass = $("#newpass").val().trim();
                var regPass = /^(?=.*[!@#$%^&*()_+{}\[\]:;<>,.?~\\/-]).{5,}$/;

                $(".error").text(""); // Clear previous errors

                if (oldpass === "") {
                    $("#oldpassError").text("Password cannot be empty!");
                    valid = false;
                }

                if (pass === "") {
                    $("#passError").text("New password cannot be empty!");
                    valid = false;
                } else if (!regPass.test(pass)) {
                    $("#passError").text("Password must be at least 5 characters and contain 1 special character.");
                    valid = false;
                } else if (oldpass === pass) {
                    $("#passError").text("New password cannot be the same as the old password.");
                    valid = false;
                }

                if (newpass === "") {
                    $("#newpassError").text("Please confirm your password!");
                    valid = false;
                } else if (pass !== newpass) {
                    $("#newpassError").text("Passwords do not match!");
                    valid = false;
                }
                if (!valid) {
                    e.preventDefault();
                }
            });
        });
        // Ajax
        $(document).ready(function() {
            $("#oldpass").on("input", function() {
                var oldpass = $(this).val();
                var id = <?php echo $id; ?>;
                if (oldpass === "") {
                    $("#oldpassError").text("");
                    return;
                }

                if (oldpass) {
                    $.ajax({
                        type: "POST",
                        url: "get_change_pass.php",
                        data: {
                            oldpass: oldpass,
                            id: id
                        },
                        success: function(response) {
                            if (response === "invalid") {
                                $("#oldpassError").text("Wrong password!");
                            } else {
                                $("#oldpassError").text("");
                            }

                        }
                    });
                }
            });
        });
        // Function
        function showoldPassword() {
            var pass = document.getElementById("oldpass");
            pass.type = (pass.type === "password") ? "text" : "password";
        }

        function shownewPassword() {
            var pass = document.getElementById("newpass");
            pass.type = (pass.type === "password") ? "text" : "password";
        }
    </script>
</body>

</html>
<?php $con->close(); ?>