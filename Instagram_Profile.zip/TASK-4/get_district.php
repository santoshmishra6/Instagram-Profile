<?php
require('db.php');

if (isset($_POST['id'])) {
    $id = $_POST['id'];
    echo $id;
    $sql = "SELECT * FROM district WHERE state_id = '$id'";
    $result = $con->query($sql);

    echo '<option value="">---Select District---</option>';
    while ($row = $result->fetch_assoc()) {
        echo "<option value='" . ($row['id']) . "'>" . ($row['name']) . "</option>";
    }
}
$con->close();
?>
