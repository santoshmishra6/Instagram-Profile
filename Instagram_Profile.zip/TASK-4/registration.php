<?php
require("db.php");
$msg="";
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = ucwords(trim($_POST['name']));
    $mobile = trim($_POST['mobile']);
    $add = trim($_POST['add']);
    $state = $_POST['state'];
    $district = $_POST['district'];
    $city = $_POST['city'];
    $username = trim($_POST['username']);
    $pass = md5($_POST['pass']);

    $photo_dir = "photo/";
    $attachment_dir = "attachment/";

    // File upload validation for Photo
    $target_photo = $photo_dir . basename($_FILES["photo"]["name"]);
    $photoFileType = strtolower(pathinfo($target_photo, PATHINFO_EXTENSION));

    $uploadOk = 1;

    // if (file_exists($target_photo)) {
    //     echo "<script>alert('Photo already exists.');</script>";
    //     $uploadOk = 0;
    // }


    // if ($photoFileType != "jpg" && $photoFileType != "png" && $photoFileType != "jpeg" && $photoFileType != "gif") {
    //     echo "<script>alert('Sorry, only JPG, JPEG, PNG & GIF files are allowed.');</script>";
    //     $uploadOk = 0;
    // }

    // Insert into database if photo is uploaded
    $user_sql = "SELECT COUNT(*) as count FROM registration WHERE username='$username'";
    $result_user = $con->query($user_sql);

    if ($result_user->num_rows > 0) {
        $msg="<div class='alert alert-danger'>Username Already Exists.</div>";
        // echo "<script>alert('Username Already Exists'); window.location='registration.php';</script>";
    } else {
        if ($uploadOk == 1 && move_uploaded_file($_FILES["photo"]["tmp_name"], $target_photo)) {
            $sql = "INSERT INTO registration (name, mobile, address, state, district, city, username, pass, photos) 
                VALUES ('$name', '$mobile', '$add', '$state', '$district', '$city', '$username', '$pass', '$target_photo')";

            $result = $con->query($sql);

            if ($result) {
                $last_insert_id = $con->insert_id;
            } else {
                $msg = '<div class="alert alert-danger">Error in registration.</div>';
                // echo "<script>alert('Error in registration.');</script>";
                // exit;
            }
        } else {
            $msg = '<div class="alert alert-danger">Error uploading photo.</div>';
            // echo "<script>alert('Error uploading photo.'); </script>";
            // exit;
        }
        // Academic Section
        $board_array = $_POST['board'];

        foreach ($board_array as $key => $board) {
            $board;
            $course = $_POST['course'][$key];
            $percentage = trim($_POST['percentage'][$key]);
            $total_marks = trim($_POST['tm'][$key]);
            $secure_marks = trim($_POST['sm'][$key]);
            $target_file = basename($_FILES["file"]["name"][$key]);

            $file = $attachment_dir . $target_file;

            if (move_uploaded_file($_FILES["file"]["tmp_name"][$key], $file)) {
                $sql2 = "INSERT INTO academic (reg_id, course, board, percentage, total_mark, secure_mark, attachment) 
                 VALUES ('$last_insert_id', '$course', '$board', '$percentage', '$total_marks', '$secure_marks', '$file')";

                $result2 = $con->query($sql2);

                if ($result2) {
                    echo "<script>alert('Registration Successful!')
                window.location='index.php';
             </script>";
                } else {
                    $msg="<div class='alert alert-danger'>Error in insert academic details.</div>";
                }
            } else {
                $msg="<div class='alert alert-danger'>Error uploading file.</div>";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/css/bootstrap.min.css"
        integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <style>
        body {
            background-image: linear-gradient(to right,rgba(14, 68, 167, 0.7),rgba(3, 79, 255, 0.89));
            background-repeat: no-repeat;
        }
     .password-container {
            position: relative;
            display: flex;
            align-items: center;
            width: 100%;
        }

        .form-control {
            width: 100%;
            padding-right: 40px;
            /* Space for the button */
        }

        .toggle-btn {
            position: absolute;
            right: 10px;
            background: none;
            border: none;
            cursor: pointer;
            outline: none;
        }

        .toggle-btn svg {
            width: 20px;
            height: 20px;
        }

        .error {
            color: rgb(255, 0, 0);
        }
    </style>
    <title>Registration Form</title>
</head>

<body>
    <div class="container mt-5">
        <div class="card p-4 shadow">
            <h3 class="text-center">Registration Form</h3>
            <?php echo $msg; ?>
            <form action="" method="post" enctype="multipart/form-data" id="myForm">
                <!-- Personal Information Section -->
                <div class="form-row">
                    <div class="form-group col-md-6">
                        <label for="inputName">Name</label>
                        <input type="text" name="name" class="form-control" id="name" placeholder="Enter full name">
                        <div class="error" id="nameError"></div>
                    </div>
                    <div class="form-group col-md-6">
                        <label for="inputPhone">Phone Number</label>
                        <input type="tel" name="mobile" class="form-control" id="mobile" placeholder="Enter phone number">
                        <div class="error" id="mobileError"></div>
                    </div>
                </div>
                <div class="form-group]">
                    <label for="photo">Photo</label>
                    <input type="file" name="photo" class="form-control-file" id="photo">
                    <div class="error" id="photoError"></div>
                </div>
                <hr>

                <!-- Address Section -->
                <div class="form-group">
                    <label for="inputAddress">Address</label>
                    <textarea class="form-control" id="add" name="add" placeholder="Street Address"></textarea>
                    <div class="error" id="addError"></div>
                </div>
                <div class="form-row">
                    <div class="form-group col-md-4">
                        <label for="state">State</label>
                        <select id="state" name="state" class="form-control">
                            <option value="">Choose...</option>
                            <?php
                            require('db.php');
                            $sql = "SELECT * FROM state";
                            $res = $con->query($sql);
                            while ($row = $res->fetch_assoc()) {
                                echo '<option value="' . $row['id'] . '">' . $row['name'] . '</option>';
                            }
                            ?>
                        </select>
                        <div class="error" id="stateError"></div>
                    </div>
                    <div class="form-group col-md-4">
                        <label for="district">District</label>
                        <select id="district" name="district" class="form-control">
                            <option value="">Choose...</option>
                        </select>
                        <div class="error" id="districtError"></div>
                    </div>
                    <div class="form-group col-md-4">
                        <label for="city">City</label>
                        <select id="city" name="city" class="form-control">
                            <option value="">Choose...</option>
                        </select>
                        <div class="error" id="cityError"></div>
                    </div>
                </div>

                <hr>
                <!-- Academic Section -->
                <div class="form-group">
                    <label><b>Academic Details</b></label>
                </div>
                <table class="table table-border)">
                    <thead class="thead-light">
                        <tr>
                            <th>Board</th>
                            <th>Course</th>
                            <th>Total Marks</th>
                            <th>Secure Marks</th>
                            <th>Percentage</th>
                            <th>Attachment</th>
                            <th class="text-center" rowspan="2">
                                <button type="button" class="btn btn-outline-success" id="add" onclick="myFunction()"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-plus-lg" viewBox="0 0 16 16">
                                        <path fill-rule="evenodd" d="M8 2a.5.5 0 0 1 .5.5v5h5a.5.5 0 0 1 0 1h-5v5a.5.5 0 0 1-1 0v-5h-5a.5.5 0 0 1 0-1h5v-5A.5.5 0 0 1 8 2" />
                                    </svg></button>
                            </th>
                        </tr>
                    </thead>

                    <tbody id="dropdown-container">
                        <tr class="dropdown">
                            <td>
                                <div class="error form-group " id="boardError"></div>
                                <select name="board[]" class="form-control board" id="board">
                                    <option value="">Choose...</option>
                                    <option>HSC</option>
                                    <option>CHSE</option>
                                    <option>Graduation</option>
                                    <option>Masters</option>
                                </select>

                            </td>
                            <td>
                                <div class="error form-group " id="courseError"></div>
                                <select name="course[]" class="form-control course" id="course">
                                    <option value="">Choose...</option>
                                    <option>10th</option>
                                    <option>12th</option>
                                    <option>BSC</option>
                                    <option>MCA</option>
                                    <option>MBA</option>
                                </select>

                            </td>
                            <td>
                                <div class="error form-group " id="totalmarkError"></div>
                                <input type="tel" id="total_mark" name="tm[]" class="form-control total_mark" placeholder="Enter total marks">

                            </td>

                            <td>
                                <div class="error form-group" id="securemarkError"></div>
                                <input type="tel" id="secure_mark" name="sm[]" class="form-control secure_mark" placeholder="Enter securgb(248, 27, 252) marks">

                            </td>
                            <td>
                                <div class="error form-group " id="percentageError"></div>
                                <input type="tel" id="percentage" name="percentage[]" class="form-control percentage" placeholder="Enter %">

                            </td>

                            <td>
                                <div class="error form-group " id="attachmentError"></div>
                                <input type="file" id="attachment" name="file[]" class="form-control-file attachment">

                            </td>

                            <td class="text-center">
                                <button type="button" class="btn btn-outline-danger remove-btn" id="remove"><i class="bi bi-twitter-x"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-twitter-x" viewBox="0 0 16 16">
                                            <path d="M12.6.75h2.454l-5.36 6.142L16 15.25h-4.937l-3.867-5.07-4.425 5.07H.316l5.733-6.57L0 .75h5.063l3.495 4.633L12.601.75Zm-.86 13.028h1.36L4.323 2.145H2.865z" />
                                        </svg></i></button>
                            </td>
                        </tr>
                    </tbody>
                </table>
                <hr>

                <!-- Login Section -->
                <div class="form-group">
                    <label><b>Login Details</b></label>
                </div>
                <div class="form-group">
                    <label for="username">Username</label>
                    <input type="text" class="form-control" name="username" id="username" placeholder="Enter username">
                    <div class="error form-group" id="usernameError"></div>
                </div>
                <div class="form-group">
                    <label for="loginPassword">Password</label>
                    <div class="password-container">
                        <input type="password" class="form-control" id="pass" name="pass" placeholder="Enter password">
                        <button class="toggle-btn" type="button" onclick="showPassword()">
                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-eye" viewBox="0 0 16 16">
                                <path d="M16 8s-3-5.5-8-5.5S0 8 0 8s3 5.5 8 5.5S16 8 16 8M1.173 8a13 13 0 0 1 1.66-2.043C4.12 4.668 5.88 3.5 8 3.5s3.879 1.168 5.168 2.457A13 13 0 0 1 14.828 8q-.086.13-.195.288c-.335.48-.83 1.12-1.465 1.755C11.879 11.332 10.119 12.5 8 12.5s-3.879-1.168-5.168-2.457A13 13 0 0 1 1.172 8z" />
                                <path d="M8 5.5a2.5 2.5 0 1 0 0 5 2.5 2.5 0 0 0 0-5M4.5 8a3.5 3.5 0 1 1 7 0 3.5 3.5 0 0 1-7 0" />
                            </svg>
                        </button>
                    </div>
                </div>
                <div class="error form-group" id="passError"></div>
                <div class="form-group">
                    <label for="confirmPassword">Confirm Password</label>
                    <div class="password-container">
                        <input type="password" class="form-control" name="cmpass" id="confirmPassword" placeholder="Confirm password">
                        <button class="toggle-btn" type="button" onclick="showconfirmPassword()">
                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-eye" viewBox="0 0 16 16">
                                <path d="M16 8s-3-5.5-8-5.5S0 8 0 8s3 5.5 8 5.5S16 8 16 8M1.173 8a13 13 0 0 1 1.66-2.043C4.12 4.668 5.88 3.5 8 3.5s3.879 1.168 5.168 2.457A13 13 0 0 1 14.828 8q-.086.13-.195.288c-.335.48-.83 1.12-1.465 1.755C11.879 11.332 10.119 12.5 8 12.5s-3.879-1.168-5.168-2.457A13 13 0 0 1 1.172 8z" />
                                <path d="M8 5.5a2.5 2.5 0 1 0 0 5 2.5 2.5 0 0 0 0-5M4.5 8a3.5 3.5 0 1 1 7 0 3.5 3.5 0 0 1-7 0" />
                            </svg>
                        </button>
                    </div>
                </div>
                <div class="error form-group" id="cmpassError"></div>

                <!-- Submit Button -->
                <button type="submit" class="btn btn-primary btn-block">Submit</button>
            </form>
        </div>
    </div>

    <script>

        $(document).ready(function() {
            $("#myForm").submit(function(e) {
                var valid = true;

                // Get and trim input values
                var name = $("#name").val();
                var mobile = $("#mobile").val();
                var add = $("#add").val();
                var photo = $("#photo").val();
                var state = $("#state").val();
                var district = $("#district").val();
                var city = $("#city").val();
                var username = $("#username").val();
                var pass = $("#pass").val();
                var cmpass = $("#confirmPassword").val();

                var regPass = /^(?=.*[!@#$%^&*()_+{}\[\]:;<>,.?~\\/-]).{5,}$/;
                var regMobile = /^[6-9][0-9]{9}$/;
                var num = /^-?\d+(\.\d+)?$/;
                var space = /^\s/;
                $(".error").text("");
                $("input, select").css("border-color", "");

                if (name === "") {
                    $("#nameError").text("Name cannot be empty!");
                    $("#name").css("border-color", "red");
                    valid = false;
                } else if (space.test(name)) {
                    $("#nameError").text("Name should not start with spaces!");
                    $("#name").css("border-color", "red");
                    valid = false;
                }

                if (mobile === "") {
                    $("#mobileError").text("Mobile number cannot be empty!");
                    $("#mobile").css("border-color", "red");
                    valid = false;
                } else if (space.test(mobile)) {
                    $("#mobileError").text("Mobile should not start with spaces!");
                    $("#mobile").css("border-color", "red");
                    valid = false;
                } else if (!regMobile.test(mobile)) {
                    $("#mobileError").text("Please enter a valid mobile number");
                    $("#mobile").css("border-color", "red");
                    valid = false;
                }

                if (add === "") {
                    $("#addError").text("Address cannot be empty!");
                    $("#add").css("border-color", "red");
                    valid = false;
                } else if (space.test(add)) {
                    $("#addError").text("Address should not start with spaces!");
                    $("#add").css("border-color", "red");
                    valid = false;
                }

                if (photo === "") {
                    $("#photoError").text("Please upload a photo.").css("color", "red");
                    valid = false;
                }

                if (state === "") {
                    $("#stateError").text("Please select a state.");
                    $("#state").css("border-color", "red");
                    valid = false;
                }

                if (district === "") {
                    $("#districtError").text("Please select a district.");
                    $("#district").css("border-color", "red");
                    valid = false;
                }

                if (city === "") {
                    $("#cityError").text("Please select a city.");
                    $("#city").css("border-color", "red");
                    valid = false;
                }

                if (username === "") {
                    $("#usernameError").text("Username cannot be empty!");
                    $("#username").css("border-color", "red");
                    valid = false;
                } else if (space.test(username)) {
                    $("#usernameError").text("Username should not start with spaces!");
                    $("#username").css("border-color", "red");
                    valid = false;
                }

                if (pass === "") {
                    $("#passError").text("Password cannot be empty!");
                    $("#pass").css("border-color", "red");
                    valid = false;
                } else if (space.test(pass)) {
                    $("#passError").text("Password Should not start with spaces!");
                    $("#pass").css("border-color", "red");
                    valid = false;
                } else if (!regPass.test(pass)) {
                    $("#passError").text("Password must be at least 5 characters and contain 1 special character.");
                    $("#pass").css("border-color", "red");
                    valid = false;
                }

                if (cmpass === "") {
                    $("#cmpassError").text("Please confirm your password!");
                    $("#confirmPassword").css("border-color", "red");
                    valid = false;
                } else if (space.test(cmpass)) {
                    $("#cmpassError").text("Password Should not start with spaces!");
                    $("#confirmPassword").css("border-color", "red");
                    valid = false;
                } else if (pass !== cmpass) {
                    $("#cmpassError").text("Passwords do not match!");
                    $("#confirmPassword").css("border-color", "red");
                    valid = false;
                }

                var courses_arr = [];
                var board_arr = [];
                var percentage_arr = [];
                var total_mark_arr = [];
                var secure_mark_arr = [];

                $(".board").each(function() {
                    var board = $(this).val();
                    if (!board) {
                        $(this).css("border-color", "rgb(255, 0, 0)");
                        valid = false;
                    } else if (board_arr.includes(board)) {
                        $(this).css("border-color", "rgb(255, 0, 0)");
                        valid = false;
                    }
                    board_arr.push(board);
                });

                $(".course").each(function() {
                    var course = $(this).val();
                    if (!course) {
                        $(this).css("border-color", "rgb(255, 0, 0)");
                        valid = false;
                    } else if (courses_arr.includes(course)) {
                        $(this).css("border-color", "rgb(255, 0, 0)");
                        valid = false;
                    }
                    courses_arr.push(course);
                });

                $(".percentage").each(function() {
                    var percentage = $(this).val();
                    if (!percentage) {
                        $(this).css("border-color", "rgb(255, 0, 0)");
                        valid = false;
                    } else if (!num.test(percentage)) {
                        $(this).css("border-color", "rgb(255, 0, 0)");
                        valid = false;
                    }
                    percentage_arr.push(percentage);
                });

                $(".total_mark").each(function() {
                    var total_mark = $(this).val();
                    if (!total_mark) {
                        $(this).css("border-color", "rgb(255, 0, 0)");
                        valid = false;
                    } else if (!num.test(total_mark)) {
                        $(this).css("border-color", "rgb(255, 0, 0)");
                        valid = false;
                    }
                    total_mark_arr.push(total_mark);
                });

                $(".secure_mark").each(function() {
                    var secure_mark = $(this).val();
                    if (!secure_mark) {
                        $(this).css("border-color", "rgb(255, 0, 0)");
                        valid = false;
                    } else if (!num.test(secure_mark)) {
                        $(this).css("border-color", "rgb(255, 0, 0)");
                        valid = false;
                    }
                    secure_mark_arr.push(secure_mark);
                });

                $(".secure_mark").each(function(index) {
                    var secureMark = parseFloat($(this).val()) || 0;
                    var totalMark = parseFloat($(".total_mark").eq(index).val()) || 0;

                    if (secureMark > totalMark) {
                        $(this).css("border-color", "rgb(255, 0, 0)");
                        valid = false;
                    }
                });

                $(".attachment").each(function() {
    var attachment = $(this).val();
    if (!attachment) {
        $(this).css("border", "0.1px solid red"); 
        valid = false;
    }
});


                if (!valid) {
                    e.preventDefault();
                }
            });
        });
        $(document).ready(function() {
            $("#state").change(function() {
                var stateId = $(this).val();
                if (stateId) {
                    $.ajax({
                        type: "POST",
                        url: "get_district.php",
                        data: {
                            id: stateId
                        },
                        success: function(response) {
                            $("#district").html(response);
                        }
                    });
                }
            });

            $("#district").change(function() {
                var districtId = $(this).val();
                if (districtId) {
                    $.ajax({
                        type: "POST",
                        url: "get_city.php",
                        data: {
                            id: districtId
                        },
                        success: function(response) {
                            $("#city").html(response);
                        }
                    });
                }
            });
        });
        
        $(document).ready(function() {
                        $("#username").on("input", function() {
                            var username = $(this).val().trim();
                            if (username === "") {
                                $("#usernameError").text("");
                                return;
                            }

                            if (username) {
                                $.ajax({
                                    type: "POST",
                                    url: "get_username.php",
                                    data: {
                                        username: username
                                    },
                                    success: function(response) {
                                        if (response === "invalid") {
                                            $("#usernameError").text("Username Already Exits!");
                                        } else {
                                            $("#usernameError").text("");
                                        }

                                    }
                                });
                            }
                        });
                    });

                    $(document).ready(function() {
                        $("#mobile").on("input", function() {
                            var mobile = $(this).val().trim();
                            if (mobile === "") {
                                $("#mobileError").text("");
                                return;
                            }

                            if (mobile) {
                                $.ajax({
                                    type: "POST",
                                    url: "get_mobile.php",
                                    data: {
                                        mobile: mobile
                                    },
                                    success: function(response) {
                                        if (response === "invalid") {
                                            $("#mobileError").text("Mobile Number Already Exits!");
                                        } else {
                                            $("#mobileError").text("");
                                        }

                                    }
                                });
                            }
                        });
                    });

        function showconfirmPassword() {
            var pass = document.getElementById("confirmPassword");
            pass.type = (pass.type === "password") ? "text" : "password";
        }
        $(function() {
            $(document).on('input', '.total_mark, .secure_mark', function() {
                calculate($(this).closest('.dropdown'));
            });

            function calculate(container) {
                var total_mark = parseFloat(container.find('.total_mark').val());
                var secure_mark = parseFloat(container.find('.secure_mark').val());
                var percentage = "";

                if (!isNaN(total_mark) && !isNaN(secure_mark) && total_mark > 0) {
                    percentage = ((secure_mark / total_mark) * 100).toFixed(3);
                }
                container.find('.percentage').val(percentage);
            }
        });

        function myFunction() {
            let node = document.querySelector(".dropdown");
            if (!node) {
                console.error("No element with class 'dropdown' found.");
                return;
            }

            let clone = node.cloneNode(true);

            let inputs = clone.querySelectorAll("input");
            let errors = clone.querySelectorAll(".error");

            inputs.forEach(input => input.value = "");
            errors.forEach(error => error.textContent = "");

            document.getElementById("dropdown-container").appendChild(clone);
        }

        $(document).on("click", ".remove-btn", function() {
            if ($(".dropdown").length > 1) {
                $(this).closest(".dropdown").remove();
            }

        });

        function showPassword() {
            var pass = document.getElementById("pass");
            pass.type = (pass.type === "password") ? "text" : "password";
        }
    </script>
</body>

</html>
<?php
$con->close();
?>