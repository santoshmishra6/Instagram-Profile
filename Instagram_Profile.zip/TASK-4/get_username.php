<?php
require('db.php');

if ($_SERVER['REQUEST_METHOD'] == "POST") {
    $username = $_POST['username'];
    $sql = "select username from registration where username='$username'";
    $result = $con->query($sql);
    if ($result->num_rows > 0) {
        echo 'invalid';
    } else {
        echo 'valid';
    }
}
$con->close();
?>