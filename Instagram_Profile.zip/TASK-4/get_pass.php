<?php
require('db.php');

if ($_SERVER['REQUEST_METHOD'] == "POST") {
    $pass = md5($_POST['pass']);
    $username = $_POST['username'];
    $sql = "select pass from registration where username='$username'";
    $result = $con->query($sql);
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        if ($pass === $row['pass']) {
            echo 'valid';
        } else {
            echo 'invalid';
        }
    } else {
        echo 'invalid';
    }
}
$con->close();
?>