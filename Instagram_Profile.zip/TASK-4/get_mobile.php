<?php
require('db.php');

if ($_SERVER['REQUEST_METHOD'] == "POST") {
$mobile = $_POST['mobile'];
    $sql = "select mobile from registration where mobile='$mobile'";
    $result = $con->query($sql);
    if ($result->num_rows > 0) {
        echo 'invalid';
    } else {
        echo 'valid';
    }
}
$con->close();
?>