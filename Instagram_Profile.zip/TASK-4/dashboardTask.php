<?php
require("db.php");
session_start();
$id = isset($_SESSION['id']) ? $_SESSION['id'] : 0;

if ($id > 0) {
    $sql = "SELECT * FROM task WHERE reg_id='$id'";
    $result = $con->query($sql);
} else {
    header("location:index.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Task Assignment</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <style>
        body {
            background: linear-gradient(135deg, #1e3c72, #2a5298);
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            font-family: Arial, sans-serif;
            padding: 20px;
        }

        .container {
            max-width: 900px;
        }

        .card {
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(10px);
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
            color: white;
            text-align: center;
        }

        .btn {
            font-size: 16px;
            border-radius: 10px;
            transition: transform 0.2s ease-in-out;
        }

        .btn:hover {
            transform: scale(1.05);
        }

        table {
            margin-top: 20px;
            border-collapse: collapse;
        }

        th,
        td {
            text-align: center;
            vertical-align: middle;
            padding: 10px;
        }

        th {
            background-color: #343a40;
            color: white;
        }

        .action {
            border: none;
            width: 100%;
            padding: 5px;
            text-align: center;
            border-radius: 5px;
            cursor: pointer;
        }

        .disabled {
            pointer-events: none;
            background-color: #ddd !important;
            color: #999 !important;
        }
    </style>
</head>

<body>
    <div class="container">
        <div class="card shadow-lg p-4">
            <h2 class="text-center mb-4">Task Assignment</h2>
            <div class="d-flex justify-content-between mb-3">
                <a href="view.php" class="btn btn-secondary">Back</a>
                <a href="addTask.php" class="btn btn-success">Add Task</a>
            </div>
            <table class="table table-striped table-bordered text-white">
                <thead class="table-dark">
                    <tr>
                        <th scope="col">SL No.</th>
                        <th scope="col">Task</th>
                        <th scope="col">Description</th>
                        <th scope="col">Status</th>
                        <th scope="col" colspan="2">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    if (isset($result) && $result->num_rows > 0) {
                        $count = 1;
                        while ($row = $result->fetch_assoc()) {
                            $task_id = $row['id'];
                            $task = $row['task'];
                            $description = $row['description'];
                            $status = $row['status'];

                            // Check if the task status is 'completed'
                            $is_disabled = ($status == 'completed') ? "disabled style='background-color:rgba(255,0,0,.4)'" : ""; 
                            $edit_disabled = ($status == 'completed') ? "disabled" : ""; 
                          
                    ?>
                            <tr>
                                <td><?php echo $count++; ?></td>
                                <td><?php echo $task; ?></td>
                                <td><?php echo $description; ?></td>
                                <td><?php echo $status; ?></td>
                                <td>
                                    <form action="" method="post">
                                        <input type="hidden" name="task_id" value="<?php echo $task_id; ?>">
                                        <select class="action form-select" name="select" <?php echo $is_disabled; ?> onchange="this.form.submit()" style="background-color:rgb(0, 255, 55)">
                                            <option value="pending" <?php echo ($status == 'pending') ? 'selected' : ''; ?> style="background: #ffc107; color: black;">Pending&nbsp;&nbsp;&nbsp;</option>
                                            <option value="completed" <?php echo ($status == 'completed') ? 'selected' : ''; ?> style="background: #28a745; color: white;">Completed&nbsp;&nbsp;&nbsp;</option>
                                            <option value="inprogress" <?php echo ($status == 'inprogress') ? 'selected' : ''; ?> style="background: #17a2b8; color: white;">In Progress&nbsp;&nbsp;&nbsp;</option>
                                        </select>
                                    </form>
                                </td>
                                <td>
                                    <button class="btn btn-primary" <?php echo $edit_disabled; ?> onclick="window.location='edit.php?id=<?php echo $task_id;?>'">Edit</button>
                                    <?php
                                    // if($status!='completed')
                                    // echo '<a href="edit.php?id=<?php echo $task_id;?>
                                    <!-- " class="btn btn-primary">Edit</a>'; -->

                                     <!-- ?> -->
                                </td>
                            </tr>
                    <?php
                        }
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>

<?php
if (isset($_POST['task_id']) && isset($_POST['select'])) {
    $task_id = $_POST['task_id'];
    $action = $_POST['select'];
    // $action = $con->real_escape_string($action);
        $sql = "UPDATE task SET status='$action', action='$action' WHERE id = $task_id";
        if ($con->query($sql)) {
            echo '<script>alert( "Status Updated Successfully");
            window.location="dashboardTask.php";</script>';
        } else {
            echo '<script>alert( "Error=.....");
            window.location="dashboardTask.php";</script>';
        }
    }

$con->close();
?>
