<?php
session_start();
require("db.php");
$msg = "";

if (!isset($_SESSION['id'])) {
 header("location:index.php");
  exit();
}

$id = isset($_SESSION['id']) ? intval($_SESSION['id']) : 0;
$name = $mobile = $address = $state = $district = $city = $username = $pass = $photo = $state_id = $district_id = $city_id = "";

if ($id > 0) {
  $result = $con->query("SELECT r.*, 
    s.name as state_name, d.name as district_name, c.name as city_name 
FROM `registration` r
INNER JOIN `state` s ON r.state = s.id
INNER JOIN `district` d ON r.district = d.id
INNER JOIN `city` c ON r.city = c.id
WHERE r.id = '$id'");
  if ($row = $result->fetch_assoc()) {
    $name = $row['name'];
    $mobile = $row['mobile'];
    $address = $row['address'];
    $state = $row['state_name'];
    $district = $row['district_name'];
    $city = $row['city_name'];
    $state_id = $row['state'];
    $district_id = $row['district'];
    $city_id = $row['city'];
    $username = $row['username'];
    $photo = $row['photos'];
  }
}




if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $name = ucwords(trim($_POST['name']));
  $mobile = trim($_POST['mobile']);
  $add = trim($_POST['add']);
  $state = $_POST['state'];
  $district = $_POST['district'];
  $city = $_POST['city'];

  // File upload validation for Photo
  $photo_sql = "SELECT photos FROM registration WHERE id='$id'";
  $result_photo = $con->query($photo_sql);
  $photo_row = $result_photo->fetch_assoc();
  $photo = isset($photo_row['photos']) ? $photo_row['photos'] : '';


  // Handling photo upload
  if (!empty($_FILES["photo"]["name"])) {
    $photo = "photo/" . basename($_FILES["photo"]["name"]);
    move_uploaded_file($_FILES["photo"]["tmp_name"], $photo);
  }

  // Update Registration Table
  $sql = "UPDATE registration SET 
              name='$name', 
              mobile='$mobile', 
              address='$add', 
              state='$state', 
              district='$district', 
              city='$city', 
              photos='$photo' 
          WHERE id='$id'";
  $attachments = [];
  $fetch_attachments_sql = "SELECT id, attachment FROM academic WHERE reg_id='$id'";
  $fetch_attachments_result = $con->query($fetch_attachments_sql);
  while ($row = $fetch_attachments_result->fetch_assoc()) {
    $attachments[] = $row['attachment'];
  }

  if ($con->query($sql)) {
    $delete_sql = "delete from academic where reg_id='$id'";
    $result_delete = $con->query($delete_sql);
    // Academic Section
    if (isset($_POST['board'])) {
      $board_array = $_POST['board'];
      foreach ($board_array as $key => $board) {
        $board;
        $course = $_POST['course'][$key];
        $percentage = trim($_POST['percentage'][$key]);
        $total_marks = trim($_POST['tm'][$key]);
        $secure_marks = trim($_POST['sm'][$key]);

        $file = isset($attachments[$key]) ? $attachments[$key] : '';

        if (isset($_FILES["file"]["name"][$key]) && !empty($_FILES["file"]["name"][$key])) {
          $file = "attachment/" . basename($_FILES["file"]["name"][$key]);
          move_uploaded_file($_FILES["file"]["tmp_name"][$key], $file);
        }

        $sql2 = "INSERT INTO academic (reg_id, course, board, percentage, total_mark, secure_mark, attachment) 
      VALUES ('$id', '$course', '$board', '$percentage', '$total_marks', '$secure_marks', '$file')";
        $result2 = $con->query($sql2);

        if ($result2) {
          echo "<script>alert('Update Successful!'); window.location='view.php';</script>";
        } else {
          echo "<script>alert('Error updating academic details.');</script>";
        }
      }
    } else {
      $msg = '<div class="alert alert-danger">Please Fill Up Below Details</div>';
    }
  }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">

  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/css/bootstrap.min.css"
    integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
  <style>
    body {
      background: linear-gradient(135deg, #1e3c72, #2a5298);
    }

    .error {
      color: rgb(255, 0, 0)
    }
  </style>
  <title>Registration Form</title>
</head>

<body>
  <div class="container mt-5">
    <div class="card p-4 shadow">

      <form action="" method="post" enctype="multipart/form-data" id="myForm">
        <a href="view.php" class="form-group btn btn-secondary ">Back</a>
        <!-- Personal Information Section -->
        <div class="form-row">
          <div class="form-group col-md-6">
            <label for="inputName">Name</label>
            <input type="text" name="name" class="form-control" id="name" placeholder="Enter full name" value="<?php echo $name; ?>">
            <div class="error" id="nameError"></div>
          </div>

          <div class="form-group col-md-6">
            <label for="inputPhone">Phone Number</label>
            <input type="tel" name="mobile" class="form-control" id="mobile" placeholder="Enter phone number" value="<?php echo $mobile; ?>">
            <div class="error" id="mobileError"></div>
          </div>
        </div>

        <div class="form-group]">
          <label for="photo">Photo</label>
          <input type="file" name="photo" class="form-control-file" id="photo">
          <?php if ($photo) echo "<img src='" . $photo . "' alt='photo' width='100' height='100'>"; ?>
          <div class="error" id="photoError"></div>
        </div>
        <hr>

        <!-- Address Section -->
        <div class="form-group">
          <label for="inputAddress">Address</label>
          <textarea class="form-control" id="add" name="add" placeholder="Street Address"><?php echo ucfirst($address); ?></textarea>
          <div class="error" id="addError"></div>
        </div>
        <div class="form-row">
          <div class="form-group col-md-4">
            <label for="state">State</label>
            <select id="state" name="state" class="form-control">
              <option value="<?php
                              echo $state_id;
                              ?>" selected>
                <?php
                echo $state;
                ?></option>
              <?php
              require('db.php');
              $sql = "SELECT * FROM state";
              $res = $con->query($sql);
              while ($row = $res->fetch_assoc()) {
                echo '<option value="' . $row['id'] . '">' . $row['name'] . '</option>';
              }
              ?>
            </select>
            <div class="error" id="stateError"></div>
          </div>
          <div class="form-group col-md-4">
            <label for="district">District</label>
            <select id="district" name="district" class="form-control">
              <option value="<?php
                              echo $district_id;
                              ?>" selected>
                <?php
                echo $district;
                ?></option>
            </select>
            <div class="error" id="districtError"></div>
          </div>
          <div class="form-group col-md-4">
            <label for="city">City</label>
            <select id="city" name="city" class="form-control">
              <option value="<?php
                              echo $city_id;
                              ?>" selected>
                <?php
                echo $city;
                ?></option>
            </select>
            <div class="error" id="cityError"></div>
          </div>
        </div>

        <hr>
        <!-- Academic Section -->
        <div class="form-group">
          <label><b>Academic Details</b></label>
        </div>
        <?php echo $msg; ?>
        <table class="table table-border">
          <thead class="thead-light">
            <tr>
              <th>Board</th>
              <th>Course</th>
              <th>Total Marks</th>
              <th>Secure Marks</th>
              <th>Percentage</th>
              <th>Attachment</th>
              <th class="text-center">
                <button type="button" class="btn btn-outline-success" id="addbtn" onclick="myFunction()">
                  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-plus-lg" viewBox="0 0 16 16">
                    <path fill-rule="evenodd" d="M8 2a.5.5 0 0 1 .5.5v5h5a.5.5 0 0 1 0 1h-5v5a.5.5 0 0 1-1 0v-5h-5a.5.5 0 0 1 0-1h5v-5A.5.5 0 0 1 8 2" />
                  </svg>
                </button>
              </th>
            </tr>
          </thead>

          <tbody>
            <?php
            $academic_sql = "SELECT * FROM academic WHERE reg_id='$id'";
            $result_sql = $con->query($academic_sql);

            while ($academic_row = $result_sql->fetch_assoc()) :
            ?>
              <tr>
                <td>
                  <select name="board[]" class="form-control">
                    <option value="<?php
                                    echo ($academic_row['board']);
                                    ?>" selected>
                      <?php
                      echo ($academic_row['board']);
                      ?>
                    </option>
                    <option>HSC</option>
                    <option>CHSE</option>
                    <option>Graduation</option>
                    <option>Masters</option>
                  </select>
                </td>

                <td>
                  <select name="course[]" class="form-control">
                    <option value="<?php
                                    echo ($academic_row['course']);
                                    ?>" selected>
                      <?php
                      echo ($academic_row['course']);
                      ?>
                    </option>
                    <option>10th</option>
                    <option>12th</option>
                    <option>BSC</option>
                    <option>MCA</option>
                    <option>MBA</option>
                  </select>
                </td>
                <td>
                  <input type="text" name="tm[]" id="tm" class="form-control" placeholder="Enter total marks" value="<?php echo ($academic_row['total_mark']); ?>">
                </td>

                <td>
                  <input type="text" name="sm[]" class="form-control" placeholder="Enter secure marks" id="sm" value="<?php echo ($academic_row['secure_mark']); ?>">
                </td>
                <td>
                <input type="text" name="percentage[]" id="percentage" class="form-control" placeholder="Enter %" value="<?php echo ($academic_row['percentage']); ?>">
                </td>
                <td>
                  <?php if (!empty($academic_row['attachment'])) ?>
                  <a href="<?php echo ($academic_row['attachment']); ?>" target="_blank">View File</a>
                  <input type="file" name="file[]" class="form-control-file" id="file">
                </td>

                <td class="text-center">
                  <button type="button" class="btn btn-outline-danger remove-btn1" onclick="removeme()">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-twitter-x" viewBox="0 0 16 16">
                      <path d="M12.6.75h2.454l-5.36 6.142L16 15.25h-4.937l-3.867-5.07-4.425 5.07H.316l5.733-6.57L0 .75h5.063l3.495 4.633L12.601.75Zm-.86 13.028h1.36L4.323 2.145H2.865z" />
                    </svg>
                  </button>
                </td>
              </tr>
              <tr id="tr" class="academic">

              </tr>
            <?php
            endwhile;
            ?>
          </tbody>
        </table>
        <hr>


        <!-- Login Section -->
        <div class="form-group">
          <label><b>Login Details</b></label>
        </div>
        <div class="form-group">
          <label>Username</label>
          <div class="form-control"><?php echo $username; ?></div> <br>
        <!-- Submit Button -->
        <button type="submit" class="btn btn-primary btn-block">Submit</button>
      </form>
    </div>
  </div>

  <script>
    $(document).ready(function() {
      $(document).on("click", ".remove-btn1", function() {
        $(this).closest("tr").remove();
      });
    });
    $(document).ready(function() {
      let count = 1;
      $('#addbtn').click(function() {
        let dynamicRowHTML = `
            <tr class="append">
                <td>
                    <select name="board[]" class="form-control board2">
                        <option value="">Choose...</option>
                        <option>HSC</option>
                        <option>CHSE</option>
                        <option>Graduation</option>
                        <option>Masters</option>
                    </select>
                </td>
                <td>
                    <select name="course[]" class="form-control course2">
                        <option value="">Choose...</option>
                        <option>10th</option>
                        <option>12th</option>
                        <option>BSC</option>
                        <option>MCA</option>
                        <option>MBA</option>
                    </select>
                </td>
                <td> <div class="error" id="totalmarkError"></div>
                    <input type="text" name="tm[]" class="form-control total_mark2" placeholder="Enter total marks">
                </td>
               
                <td>
                <div class="error" id="securemarkError"></div>
                    <input type="text" name="sm[]" class="form-control secure_mark2" placeholder="Enter securgb marks">
                </td>
                                <td><div class="error" id="percentageError"></div>
                    <input type="text" name="percentage[]" class="form-control percentage2" placeholder="Enter %">
                </td>
                <td>
                <div class="error" id="fileError"></div>
                    <input type="file" name="file[]" class="form-control-file file2">
                </td>
                <td class="text-center">
                    <button type="button" class="btn btn-outline-danger remove-btn2">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-twitter-x" viewBox="0 0 16 16">
                            <path d="M12.6.75h2.454l-5.36 6.142L16 15.25h-4.937l-3.867-5.07-4.425 5.07H.316l5.733-6.57L0 .75h5.063l3.495 4.633L12.601.75Zm-.86 13.028h1.36L4.323 2.145H2.865z"/>
                        </svg>
                    </button>
                </td>
            </tr>`;

        $('tbody').append(dynamicRowHTML);
        count++;
        $(document).on("click", ".remove-btn2", function() {
          $(this).closest("tr").remove();
        });
      });
    });

    $(function() {
            $(document).on('input', '.total_mark2, .secure_mark2', function() {
                calculate($(this).closest('.append'));
            });

            function calculate(container) {
                var total_mark = parseFloat(container.find('.total_mark2').val());
                var secure_mark = parseFloat(container.find('.secure_mark2').val());
                var percentage = "";

                if (!isNaN(total_mark) && !isNaN(secure_mark) && total_mark > 0) {
                    percentage = ((secure_mark / total_mark) * 100).toFixed(3);
                }
                container.find('.percentage2').val(percentage);
            }
        });

    $(document).ready(function() {
  $("#myForm").submit(function(e) {
    var valid = true;
    
    $(".error").text("");
    $("input, select").css("border-color", "");
    
    var name = $("#name").val().trim();
    var mobile = $("#mobile").val().trim();
    var add = $("#add").val().trim();
    var state = $("#state").val().trim();
    var district = $("#district").val().trim();
    var city = $("#city").val().trim();
    var percentage = $("#percentage").val().trim();
    var total_mark = $("#tm").val().trim();
    var secure_mark = $("#sm").val().trim();

    let photo = "<?php echo isset($photo) ? $photo : ''; ?>"

    var num = /^-?\d+(\.\d+)?$/;
    var regMobile = /^[6-9]\d{9}$/;

    if (name === "") {
      $("#nameError").text("Name cannot be empty!").css("color", "red");
      $("#name").css("border-color", "red");
      valid = false;
    }
    if (mobile === "" || !regMobile.test(mobile)) {
      $("#mobileError").text("Enter a valid mobile number!").css("color", "red");
      $("#mobile").css("border-color", "red");
      valid = false;
    }
    if (add === "") {
      $("#addError").text("Address cannot be empty!").css("color", "red");
      $("#add").css("border-color", "red");
      valid = false;
    }
    if (photo === "") {
      $("#photoError").text("Please upload a photo.").css("color", "red");
      valid = false;
    }
    if (state === "") {
      $("#stateError").text("Please select a state.").css("color", "red");
      $("#state").css("border-color", "red");
      valid = false;
    }
    if (district === "") {
      $("#districtError").text("Please select a district.").css("color", "red");
      $("#district").css("border-color", "red");
      valid = false;
    }
    if (city === "") {
      $("#cityError").text("Please select a city.").css("color", "red");
      $("#city").css("border-color", "red");
      valid = false;
    }
    
    if (percentage === "" || !num.test(percentage)) {
      $("#percentage").css("border-color", "red");
      $("#percentageError").text("Only contain numbers").css("color", "red");
      valid = false;
    }
    if (total_mark === "" || !num.test(total_mark)) {
      $("#tm").css("border-color", "red");
      $("#totalmarkError").text("Only contain numbers").css("color", "red");
      valid = false;
    }
    if (secure_mark === "" || !num.test(secure_mark)) {
      $("#sm").css("border-color", "red");
      $("#securemarkError").text("Only contain numbers").css("color", "red");
      valid = false;
    }

    $(".board2, .course2, .percentage2, .total_mark2, .secure_mark2").each(function() {
      if ($(this).val().trim() === "") {
        $(this).css("border-color", "red");
        valid = false;
      }
    });
    $(".file2").each(function() {
    var attachment = $(this).val();
    if (!attachment) {
        $(this).css("border", "0.1px solid red"); 
        valid = false;
    }
});

    $(".secure_mark2").each(function(index) {
      var secureMark = parseFloat($(this).val()) || 0;
      var totalMark = parseFloat($(".total_mark2").eq(index).val()) || 0;
      if (secureMark > totalMark) {
        $("#securemarkError").text("Secure marks cannot be greater than total marks.").css("color", "red");
        valid = false;
      }
    });

    if (!valid) e.preventDefault();
  });
});


    $(document).ready(function() {
      $("#state").change(function() {
        var stateId = $(this).val();
        if (stateId) {
          $.ajax({
            type: "POST",
            url: "get_district.php",
            data: {
              id: stateId
            },
            success: function(response) {
              $("#district").html(response);
              $("#city").html('<option value="">---Select City---</option>');
            }
          });
        }
      });
      $("#district").change(function() {
        var districtId = $(this).val();

        if (districtId) {
          $.ajax({
            type: "POST",
            url: "get_city.php",
            data: {
              id: districtId
            },
            success: function(response) {
              $("#city").html(response);
            }
          });
        }
      });
    });
  </script>

</body>

</html>
<?php
$con->close();
?>