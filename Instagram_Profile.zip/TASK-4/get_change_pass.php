<?php
require('db.php');

if ($_SERVER['REQUEST_METHOD'] == "POST") {
    $pass = md5($_POST['oldpass']);
    $id = $_POST['id'];
    $sql = "select pass from registration where id='$id'";
    $result = $con->query($sql);
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        if ($pass === $row['pass']) {
            echo 'valid';
        } else {
            echo 'invalid';
        }
    } else {
        echo 'invalid';
    }
}
$con->close();
?>
