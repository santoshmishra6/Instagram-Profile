<?php
session_start();
require("db.php");
session_destroy();
echo "<script>alert('Logout Successfully');
window.location='index.php'
;</script>";
exit;
?>
