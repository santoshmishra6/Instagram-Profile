<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>3D State Form</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/jquery.validation/1.19.3/jquery.validate.min.js"></script>

    <style>
body {
    background: linear-gradient(135deg, #1e3c72, #2a5298);
    height: 100vh;
    margin: 0; 
    display: flex;
    align-items: center; 
    justify-content: center;
}

.container {
    display: flex;
    justify-content: center;
    align-items: center;
    width: 100%;
}

/* Card Design */
.card {
    background: rgba(255, 255, 255, 0.1);
    padding: 30px;
    border-radius: 15px;
    box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
    backdrop-filter: blur(10px);
    color: white;
    text-align: center;
    width: 400px;
    transition: transform 0.3s ease-in-out;
}

.card:hover {
    transform: translateY(-5px);
}

.card input,
.card textarea {
    background: rgba(255, 255, 255, 0.2);
    border: none;
    color: white;
    padding: 12px;
    border-radius: 8px;
    width: 100%;
    box-shadow: inset 2px 2px 5px rgba(255, 255, 255, 0.2),
                inset -2px -2px 5px rgba(0, 0, 0, 0.2);
}

.card input::placeholder,
.card textarea::placeholder {
    color: rgba(255, 255, 255, 0.7);
}

.card input:focus,
.card textarea:focus {
    outline: none;
    border: 2px solid #ff4b5c;
    box-shadow: 0px 0px 8px rgba(255, 255, 255, 0.5);
}

.btn-primary {
    background-color: #ff4b5c;
    border: none;
    padding: 12px;
    border-radius: 12px;
    transition: 0.3s;
    font-size: 16px;
    box-shadow: 0px 5px 15px rgba(0, 0, 0, 0.3);
}

.btn-primary:hover {
    background-color: #ff1e3c;
    transform: scale(1.05);
    box-shadow: 0px 8px 20px rgba(255, 0, 0, 0.5);
}

.error {
    color: #ff4b5c;
    font-size: 14px;
    margin-top: 5px;
}

@media (max-width: 480px) {
    .card {
        width: 90%;
        padding: 20px;
    }
}

    </style>
</head>

<body>
    <div class="container">
        <div class="card">
            <form id="myForm" action="" method="POST">
                <div class="form-group">
                    <label for="name">Enter State Name</label>
                    <input type="text" class="form-control" id="name" name="name" placeholder="Enter Your State Name">
                    <span id="nameError" class="error" style="color: red;"></span>
                </div>
                <br>
                <button type="submit" id="submit" class="btn btn-danger w-100">Submit</button><br><br>
            </form>

            <div>
                <?php
                require('db.php');

                $sql = "SELECT name FROM state";
                $res = $con->query($sql);
                $var = 1;

                if ($res->num_rows > 0) {
                    echo "<table>
                            <tr>
                                <th>Sl No.</th>
                                <th>State Name</th>
                            </tr>";

                    while ($row = $res->fetch_assoc()) {
                        echo "<tr>
                                <td>" . $var++ . "</td>
                                <td>" . $row['name'] . "</td>
                              </tr>";
                    }
                    echo "</table>";
                }

                $con->close();
                ?>
            </div>
        </div>
    </div>

    <script>
        $(document).ready(function() {
            $("#myForm").submit(function(e) {
                var valid = true;
                var name = $("#name").val();
                var vname = /^[a-zA-Z ]+$/;

                $(".error").text("");

                if (name === "") {
                    $("#nameError").text("Please enter your State Name!");
                    valid = false;
                } else if (!vname.test(name)) {
                    $("#nameError").text("Only letters are allowed in the State Name!");
                    valid = false;
                } else if (/^\s/.test(name)) {
                    $("#nameError").text("Error: Input should not start with spaces!");
                    valid = false;
                }

                if (!valid) {
                    e.preventDefault();
                }
            });
        });
    </script>
</body>
</html>
