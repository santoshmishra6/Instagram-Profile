<?php
require('db.php');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = strtoupper($_POST['name']);
    $district_id = trim($_POST['district']);

        $sql = "SELECT * FROM city WHERE name='$name' AND district_id='$district_id'";
        $result = $con->query($sql);

        if ($result->num_rows > 0) {
            echo "<script>alert('City Already Exists');</script>";
        } else {
            $insert = "INSERT INTO city (name, district_id) VALUES ('$name', '$district_id')";
            $con->query($insert);
            echo "<script>alert('Data Inserted Successfully');
            window.location='AddCity.php';</script>";
        }
    }
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/css/bootstrap.min.css">
    <title>City Registration</title>
    <style>
        body {
            background: linear-gradient(135deg, #1e3c72, #2a5298);
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            font-family: Arial, sans-serif;
            color: white;
            padding: 20px;
        }

        .card {
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(10px);
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
            color: white;
            width: 100%;
            max-width: 500px;
            text-align: center;
        }

        .form-control {
            background: rgba(255, 255, 255, 0.2);
            border: none;
            color: white;
            padding: 10px;
            border-radius: 8px;
        }

        .form-control::placeholder {
            color: rgba(255, 255, 255, 0.7);
        }

        .btn-primary {
            background-color: #ff4b5c;
            border: none;
            padding: 10px;
            border-radius: 12px;
            transition: 0.3s;
            font-size: 16px;
        }

        .btn-primary:hover {
            background-color: #ff1e3c;
            transform: scale(1.05);
        }

        .error {
            color: #ff4b5c;
            font-size: 14px;
            text-align: left;
        }
    </style>
</head>

<body>
    <div class="card">

        <h2>City Registration</h2>
        <form id="myForm" method="POST">
        <a href="AddDistrict.php" class="btn btn-primary btn-block">Back</a>
            <div class="form-group">
                <label>Select State</label>
                <select name="state_id" id="state" class="form-control">
                    <option value="">Choose...</option>
                    <?php
                    require('db.php');
                    $res = $con->query("SELECT * FROM state");
                    while ($row = $res->fetch_assoc()) {
                        echo '<option value="' . $row['id'] . '">' . $row['name'] . '</option>';
                    }
                    ?>
                </select>
                <span id="stateError" class="error"></span>
            </div>
            <div class="form-group">
                <label>Select District</label>
                <select id="district" name="district" class="form-control">
                    <option value="">Choose...</option>
                </select>
                <span id="districtError" class="error"></span>
            </div>
            <div class="form-group">
                <label>Enter City Name</label>
                <input type="text" class="form-control" id="name" name="name" placeholder="Enter City Name">
                <span id="nameError" class="error"></span>
            </div>
            <button type="submit" class="btn btn-primary btn-block">Submit</button>
        </form>
    </div>
    <script>
        $(document).ready(function() {
            $("#state").change(function() {
                var stateId = $(this).val();
                if (stateId) {
                    $.ajax({
                        type: "POST",
                        url: "get_district.php",
                        data: {
                            id: stateId
                        },
                        success: function(response) {
                            $("#district").html(response);
                        }
                    });
                }
            });
            $("#myForm").submit(function(e) {
                var valid = true;
                var state = $("#state").val();
                var district = $("#district").val();
                var name = $("#name").val();
                var vname = /^[a-zA-Z ]+$/;
                $(".error").text("");
                if (state === "") {
                    $("#stateError").text("Please select a State");
                    valid = false;
                }
                if (district === "") {
                    $("#districtError").text("Please select a District");
                    valid = false;
                }
                if (name === "" || !vname.test(name) || /^\s/.test(name)) {
                    $("#nameError").text("Enter a valid City Name (letters only, no spaces at start)");
                    valid = false;
                }
                if (!valid) e.preventDefault();
            });
        });
    </script>
</body>

</html>