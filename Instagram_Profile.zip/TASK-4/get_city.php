<?php
require('db.php');
echo $_POST;
if (isset($_POST['id'])) {
    $id = $_POST['id'];
    $sql = "SELECT * FROM city WHERE district_id = '$id'";
    $result = $con->query($sql);

    echo '<option value="">---Select City---</option>';
    while ($row = $result->fetch_assoc()) {
        echo "<option value='" . ($row['id']) . "'>" . ($row['name']) . "</option>";
    }
}
$con->close();
?>
