<?php

session_start();
require "db.php";

if (!isset($_SESSION['id'])) {
    header("location:index.php");
    exit();
}

$id = $_SESSION['id'];

// Fetch user details
$user_sql = "SELECT r.*, 
    s.name AS state_name, d.name AS district_name, c.name AS city_name 
FROM `registration` r
INNER JOIN `state` s ON r.state = s.id
INNER JOIN `district` d ON r.district = d.id
INNER JOIN `city` c ON r.city = c.id
WHERE r.id = '$id'";

$result = $con->query($user_sql);
$user = $result->fetch_assoc();

// Fetch academic details
$academic_sql = "SELECT course, board, percentage, total_mark, secure_mark, attachment 
FROM `academic` WHERE reg_id = '$id'";

$academic_result = $con->query($academic_sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/css/bootstrap.min.css">
    <title>User Profile</title>
    <style>
        body {
            background: linear-gradient(135deg, #1e3c72, #2a5298);
            font-family: Arial, sans-serif;
            color: white;
            text-align: center;
            padding: 20px;
        }
        .profile-container {
            max-width: 700px;
            margin: auto;
            background: rgba(255, 255, 255, 0.1);
            padding: 20px;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
            backdrop-filter: blur(10px);
        }
        .profile-img {
            width: 120px;
            height: 120px;
            border-radius: 50%;
            object-fit: cover;
            border: 5px solid #fff;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
            transition: transform 0.3s ease-in-out;
        }
        .profile-img:hover{
            transform: scale(1.75);
        }
        .table {
            background: rgba(255, 255, 255, 0.2);
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
        }
        .btn {
            transition: transform 0.2s;
        }
        .btn:hover {
            transform: translateY(-3px);
        }
    </style>
</head>
<body>
    <div class="profile-container">
        <?php if ($user): ?>
            <img src="<?php echo $user['photos']; ?>" alt="User Photo" class="profile-img mb-3">
            <h3><?php echo $user["name"]; ?></h3>
            <p>Username: <?php echo $user["username"]; ?></p>
            <p><strong>Mobile:</strong> <?php echo $user["mobile"]; ?></p>
            <h4>Address</h4>
            <p><?php echo $user["address"]; ?></p>
            <p><?php echo $user["state_name"] . ', ' . $user["district_name"] . ', ' . $user["city_name"]; ?></p>
            <h4>Academic Details</h4>
            <table class="table table-bordered">
                <thead class="thead-dark">
                    <tr>
                        <th>Course</th>
                        <th>Board</th>
                        <th>Total Marks</th>
                        <th>Secure Marks</th>
                        <th>Percentage</th>
                        <th>Attachment</th>
                    </tr>
                </thead>
                <tbody>3e4
                    <?php while ($row = $academic_result->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo $row['course']; ?></td>
                            <td><?php echo $row['board']; ?></td>
                            <td><?php echo $row['total_mark']; ?></td>
                            <td><?php echo $row['secure_mark']; ?></td>
                            <td><?php echo $row['percentage']; ?></td>
                            <td><a href="<?php echo $row['attachment']; ?>" target="_blank" class="btn btn-primary">View</a></td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
            <div>
                <a href="dashboardTask.php" class="btn btn-success">Add Task</a>
                <a href="change_pass.php" class="btn btn-warning">Change Password</a>
                <a href="update.php" class="btn btn-info">Update Profile</a>
               <br><br>
                <a href="logout.php" class="btn btn-danger">Logout</a>
            </div>
        <?php endif; ?>
    </div>
</body>
</html>

<?php $con->close(); ?>
